﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing;


namespace WFApp_5
{
    public partial class Form1 : Form
    {
        private Point PreviousPoint, point; 
        private Bitmap bmp; private Pen blackPen; 
        private Graphics g;

        OpenFileDialog dialog = new OpenFileDialog();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog();
            dialog.Filter = "Image files (*.BMP, *.JPG, " "*.GIF, *.PNG)|*.bmp;*.jpg;*.gif;*.png";
            if (dialog.ShowDialog() == DialogResult.OK) {
                Image image = Image.FromFile(dialog.FileName); int width = image.Width;
                int height = image.Height; pictureBox1.Width = width; pictureBox1.Height = height;

                g = Graphics.FromImage(pictureBox1.Image);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            blackPen = new Pen(Color.Black, 4);
        }
    }
}
