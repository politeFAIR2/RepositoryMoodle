﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

public class UdpChat
{
    private static string userName;
    private static int receivePort;
    private static int sendPort;
    private static UdpClient receiveClient;
    private static UdpClient sendClient;
    private static bool _exit = false;


    public static async Task Main(string[] args)
    {
        Console.Write("Введите свое имя: ");
        userName = Console.ReadLine();

        Console.Write("Введите порт для приема сообщений: ");
        receivePort = int.Parse(Console.ReadLine());

        Console.Write("Введите порт для отправки сообщений: ");
        sendPort = int.Parse(Console.ReadLine());


        try
        {

            receiveClient = new UdpClient(receivePort);
            _ = ReceiveMessages();

            sendClient = new UdpClient();
            sendClient.EnableBroadcast = true;

            Console.WriteLine("Для отправки сообщений введите сообщение и нажмите Enter");

            while (!_exit)
            {
                string message = Console.ReadLine();
                if (string.IsNullOrEmpty(message)) continue;
                SendMessage(message);
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при работе с UDP: {ex.Message}");
        }
        finally
        {
            if (receiveClient != null)
            {
                receiveClient.Close();
                receiveClient = null;
            }

            if (sendClient != null)
            {
                sendClient.Close();
                sendClient = null;
            }
        }

    }
    static void SendMessage(string message)
    {
        string formattedMessage = $"{userName}: {message}";
        byte[] data = Encoding.UTF8.GetBytes(formattedMessage);

        try
        {
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Broadcast, sendPort);
            sendClient.Send(data, data.Length, endPoint);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при отправке сообщения: {ex.Message}");
        }
    }
    static async Task ReceiveMessages()
    {
        try
        {
            while (!_exit)
            {
                UdpReceiveResult result = await receiveClient.ReceiveAsync();
                byte[] data = result.Buffer;
                string message = Encoding.UTF8.GetString(data);
                Console.WriteLine(message);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при получении сообщения: {ex.Message}");
        }
    }
}