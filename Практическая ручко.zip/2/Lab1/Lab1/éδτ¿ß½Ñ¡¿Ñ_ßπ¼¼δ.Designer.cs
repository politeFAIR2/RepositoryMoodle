﻿namespace Lab1
{
    partial class Вычисление_суммы
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCount = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.textA = new System.Windows.Forms.TextBox();
            this.textB = new System.Windows.Forms.TextBox();
            this.textC = new System.Windows.Forms.TextBox();
            this.textSumma = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCount
            // 
            this.btnCount.Location = new System.Drawing.Point(166, 161);
            this.btnCount.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(110, 24);
            this.btnCount.TabIndex = 0;
            this.btnCount.Text = "Вычислить";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(186, 189);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(70, 24);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // textA
            // 
            this.textA.Location = new System.Drawing.Point(37, 48);
            this.textA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textA.Name = "textA";
            this.textA.Size = new System.Drawing.Size(90, 20);
            this.textA.TabIndex = 2;
            this.textA.Tag = "";
            this.textA.Text = "0";
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(140, 48);
            this.textB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(90, 20);
            this.textB.TabIndex = 3;
            this.textB.Text = "0";
            // 
            // textC
            // 
            this.textC.Location = new System.Drawing.Point(234, 48);
            this.textC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textC.Name = "textC";
            this.textC.Size = new System.Drawing.Size(90, 20);
            this.textC.TabIndex = 4;
            this.textC.Text = "0";
            // 
            // textSumma
            // 
            this.textSumma.Location = new System.Drawing.Point(37, 88);
            this.textSumma.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textSumma.Name = "textSumma";
            this.textSumma.Size = new System.Drawing.Size(90, 20);
            this.textSumma.TabIndex = 5;
            this.textSumma.Text = "0";
            // 
            // Вычисление_суммы
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 279);
            this.Controls.Add(this.textSumma);
            this.Controls.Add(this.textC);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.textA);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCount);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Вычисление_суммы";
            this.Text = "Вычисление_суммы";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCount;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.TextBox textC;
        private System.Windows.Forms.TextBox textSumma;
    }
}

