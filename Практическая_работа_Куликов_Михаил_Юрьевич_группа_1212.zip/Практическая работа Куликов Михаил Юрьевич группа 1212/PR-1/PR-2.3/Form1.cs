namespace PR_2._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtB.BackColor = System.Drawing.Color.Black;
            
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtB.BackColor = System.Drawing.Color.Red;
            
        }

        private void �����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtB.BackColor = System.Drawing.Color.Blue;
           
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.txtB.BackColor = System.Drawing.Color.Green;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
