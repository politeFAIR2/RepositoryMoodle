namespace PR_1._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cursor.Position = PointToScreen(button2.Location);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cursor.Position = PointToScreen(button1.Location);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button2.Cursor   = System.Windows.Forms.Cursors.Hand;
            button1.Cursor = System.Windows.Forms.Cursors.Hand;
           
        }
    }
}
