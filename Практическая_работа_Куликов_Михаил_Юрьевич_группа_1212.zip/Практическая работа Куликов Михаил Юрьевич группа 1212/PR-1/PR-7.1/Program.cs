﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;
using System.Threading;

public class Server
{
    private static List<TcpClient> clients = new List<TcpClient>();
    private static Dictionary<TcpClient, string> clientNames = new Dictionary<TcpClient, string>();
    private static TcpListener listener;

    public static void Main(string[] args)
    {
        try
        {
            listener = new TcpListener(IPAddress.Any, 8888);
            listener.Start();
            Console.WriteLine("Сервер запущен. Ожидание подключений...");

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                clients.Add(client);
                Thread clientThread = new Thread(HandleClient);
                clientThread.Start(client);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка сервера: {e.Message}");
        }
        finally
        {
            listener?.Stop();
        }
    }

    static void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        try
        {
            NetworkStream stream = client.GetStream();


            byte[] nameData = new byte[256];
            int bytes = stream.Read(nameData, 0, nameData.Length);
            string name = Encoding.UTF8.GetString(nameData, 0, bytes);
            clientNames.Add(client, name);
            Console.WriteLine($"{name} вошел в чат");
            BroadcastMessage($"{name} вошел в чат", null);

            while (true)
            {
                byte[] data = new byte[256];
                bytes = stream.Read(data, 0, data.Length);
                if (bytes == 0)
                {
                    break;
                }
                string message = Encoding.UTF8.GetString(data, 0, bytes);
                Console.WriteLine($"{name}: {message}");
                BroadcastMessage($"{name}: {message}", client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при работе с клиентом: {ex.Message}");
        }
        finally
        {
            string leftName = "";
            if (clientNames.ContainsKey(client))
            {
                leftName = clientNames[client];
            }

            Console.WriteLine($"{leftName} покинул чат");
            clientNames.Remove(client);
            clients.Remove(client);
            BroadcastMessage($"{leftName} покинул чат", null);

            client?.Close();

        }
    }

    static void BroadcastMessage(string message, TcpClient excludeClient)
    {
        byte[] data = Encoding.UTF8.GetBytes(message);
        foreach (TcpClient client in clients)
        {
            if (client != excludeClient && client.Connected)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(data, 0, data.Length);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при отправке сообщения клиенту: {ex.Message}");
                }
            }

        }
    }
}
