﻿namespace PR_1
{
    partial class Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstNames = new ListBox();
            btnAdd = new Button();
            txtName = new TextBox();
            Names = new Label();
            SuspendLayout();
            // 
            // lstNames
            // 
            lstNames.FormattingEnabled = true;
            lstNames.Location = new Point(12, 32);
            lstNames.Name = "lstNames";
            lstNames.Size = new Size(120, 104);
            lstNames.TabIndex = 0;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(138, 65);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 30);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "Add Name";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtName
            // 
            txtName.Location = new Point(138, 32);
            txtName.Name = "txtName";
            txtName.Size = new Size(120, 27);
            txtName.TabIndex = 2;
            // 
            // Names
            // 
            Names.AutoSize = true;
            Names.Location = new Point(12, 9);
            Names.Name = "Names";
            Names.Size = new Size(55, 20);
            Names.TabIndex = 3;
            Names.Text = "Names";
            // 
            // Form
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(287, 146);
            Controls.Add(Names);
            Controls.Add(txtName);
            Controls.Add(btnAdd);
            Controls.Add(lstNames);
            Name = "Form";
            Text = "Names";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstNames;
        private Button btnAdd;
        private TextBox txtName;
        private Label Names;
    }
}
