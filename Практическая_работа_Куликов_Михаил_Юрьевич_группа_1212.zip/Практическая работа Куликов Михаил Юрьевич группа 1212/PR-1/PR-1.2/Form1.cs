namespace PR_1._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                MessageBox.Show($"Form.KeyPress: '{e.KeyChar}' pressed");
                switch (e.KeyChar)
                {
                    case (char)49:
                    case (char)52:
                    case (char)55:
                        MessageBox.Show($"Form.KeyPress: '{e.KeyChar}' pressed");
                        e.Handled = true;
                        break;
                }
            }
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            Cursor.Hide();
        }

        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            Cursor.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
