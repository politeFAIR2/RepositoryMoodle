﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class Client
{
    private static TcpClient client;
    private static NetworkStream stream;
    private static string userName;

    public static void Main(string[] args)
    {
        try
        {
            Console.Write("Введите свое имя: ");
            userName = Console.ReadLine();

            client = new TcpClient();
            client.Connect(IPAddress.Loopback, 8888);
            stream = client.GetStream();

            byte[] nameData = Encoding.UTF8.GetBytes(userName);
            stream.Write(nameData, 0, nameData.Length);

            Console.WriteLine($"Добро пожаловать, {userName}");
            Console.WriteLine("Для отправки сообщений введите сообщение и нажмите Enter");

            Thread receiveThread = new Thread(ReceiveMessages);
            receiveThread.Start();

            while (true)
            {
                string message = Console.ReadLine();
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка клиента: {ex.Message}");
        }
        finally
        {
            stream?.Close();
            client?.Close();
        }
    }

    static void ReceiveMessages()
    {
        try
        {
            while (true)
            {
                byte[] data = new byte[256];
                int bytes = stream.Read(data, 0, data.Length);
                if (bytes == 0)
                    break;
                string message = Encoding.UTF8.GetString(data, 0, bytes);
                Console.WriteLine(message);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при чтении сообщений с сервера: {ex.Message}");
        }
    }
}
