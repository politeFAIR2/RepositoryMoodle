﻿namespace PR_2._2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            txt = new TextBox();
            lst = new ListBox();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.Location = new Point(277, 187);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(94, 29);
            btnExit.TabIndex = 0;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txt
            // 
            txt.Location = new Point(22, 187);
            txt.Name = "txt";
            txt.Size = new Size(125, 27);
            txt.TabIndex = 1;
            // 
            // lst
            // 
            lst.FormattingEnabled = true;
            lst.Location = new Point(22, 26);
            lst.Name = "lst";
            lst.Size = new Size(150, 104);
            lst.TabIndex = 2;
            lst.SelectedIndexChanged += lst_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(487, 297);
            Controls.Add(lst);
            Controls.Add(txt);
            Controls.Add(btnExit);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExit;
        private TextBox txt;
        private ListBox lst;
    }
}
