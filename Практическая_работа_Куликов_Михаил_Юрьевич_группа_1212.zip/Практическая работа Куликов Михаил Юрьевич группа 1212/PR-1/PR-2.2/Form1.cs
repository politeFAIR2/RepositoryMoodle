namespace PR_2._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lst.SelectedItem == "black")
            {
                txt.BackColor = System.Drawing.Color.Black;
            }

            else if (lst.SelectedItem == "red")
            {
                txt.BackColor = System.Drawing.Color.Red;
            }
            else if (lst.SelectedItem == "blue")
            {
                txt.BackColor = System.Drawing.Color.Blue;
            }
            else if (lst.SelectedItem == "green")
            {
                txt.BackColor = System.Drawing.Color.Green;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lst.Items.Add("black");
            lst.Items.Add("red");
            lst.Items.Add("blue");
            lst.Items.Add("green");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
