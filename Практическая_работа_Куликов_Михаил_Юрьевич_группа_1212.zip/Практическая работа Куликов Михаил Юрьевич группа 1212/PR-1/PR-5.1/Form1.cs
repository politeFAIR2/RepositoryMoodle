
using System.Drawing.Drawing2D;

namespace PR_5._1
{
   
    public partial class Form1 : Form
    {
        private Bitmap _currentBitmap;
        private bool _isDrawing = false;
        private Point _lastPoint;
        private bool _isMouseDown = false;
        public Form1()
        {
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Bitmap loadedBitmap = new Bitmap(openFileDialog.FileName);
                    _currentBitmap = new Bitmap(loadedBitmap.Width, loadedBitmap.Height);
                    using (Graphics g = Graphics.FromImage(_currentBitmap))
                    {
                        g.Clear(Color.White);
                        g.DrawImage(loadedBitmap, 0, 0, loadedBitmap.Width, loadedBitmap.Height);
                    }

                    pictureBox1.Image = _currentBitmap;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"������ �������� �����������: {ex.Message}", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("��� ����������� ��� ����������.", "��������������", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PNG Image (*.png)|*.png|JPEG Image (*.jpg)|*.jpg|Bitmap Image (*.bmp)|*.bmp";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {

                    System.Drawing.Imaging.ImageFormat format;
                    string extension = System.IO.Path.GetExtension(saveFileDialog.FileName).ToLower();

                    switch (extension)
                    {
                        case ".png":
                            format = System.Drawing.Imaging.ImageFormat.Png;
                            break;
                        case ".jpg":
                        case ".jpeg":
                            format = System.Drawing.Imaging.ImageFormat.Jpeg;
                            break;
                        case ".bmp":
                            format = System.Drawing.Imaging.ImageFormat.Bmp;
                            break;
                        default:
                            MessageBox.Show("����������� ������ �����", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                    }


                    _currentBitmap?.Save(saveFileDialog.FileName, format);
                    MessageBox.Show("����������� ���������!", "�����", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"������ ���������� �����������: {ex.Message}", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (_currentBitmap == null) return;
            _isMouseDown = true;
            _lastPoint = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isMouseDown || _currentBitmap == null) return;

            using (Graphics g = Graphics.FromImage(_currentBitmap))
            {
                using (Pen pen = new Pen(Color.Black, 3))
                {
                    pen.LineJoin = LineJoin.Round;
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.DrawLine(pen, _lastPoint, e.Location);
                }

            }
            _lastPoint = e.Location;
            pictureBox1.Invalidate();
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            _isMouseDown = false;
        }
    }
}
