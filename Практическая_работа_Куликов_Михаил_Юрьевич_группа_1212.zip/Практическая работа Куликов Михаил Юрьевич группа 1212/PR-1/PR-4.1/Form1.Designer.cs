﻿namespace PR_4._1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pct = new PictureBox();
            btn = new Button();
            file1 = new OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)pct).BeginInit();
            SuspendLayout();
            // 
            // pct
            // 
            pct.Location = new Point(142, 12);
            pct.Name = "pct";
            pct.Size = new Size(317, 316);
            pct.TabIndex = 0;
            pct.TabStop = false;
            pct.Click += pct_Click;
            // 
            // btn
            // 
            btn.Location = new Point(142, 354);
            btn.Name = "btn";
            btn.Size = new Size(317, 34);
            btn.TabIndex = 1;
            btn.Text = "Загрузить рисунок";
            btn.UseVisualStyleBackColor = true;
            btn.Click += btn_Click;
            // 
            // file1
            // 
            file1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn);
            Controls.Add(pct);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pct).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pct;
        private Button btn;
        private OpenFileDialog file1;
    }
}
