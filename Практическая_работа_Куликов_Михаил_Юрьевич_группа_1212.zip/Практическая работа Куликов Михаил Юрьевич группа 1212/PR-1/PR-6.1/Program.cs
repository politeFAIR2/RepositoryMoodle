﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Diagnostics;
using System.Security.AccessControl;

public class Program
{
    private static readonly string DirectoryPath = "C:\\";
    private const int Port = 8000;

    public static void Main(string[] args)
    {

        LoadHtmlAndDisplayRequests();

        Console.WriteLine("Нажмите любую клавишу для завершения...");
        Console.ReadKey();
    }

    static void LoadHtmlAndDisplayRequests()
    {
        string filePath = Path.Combine(DirectoryPath, "index.html");
        string responseText = "";

        try
        {
            responseText = File.ReadAllText(filePath, Encoding.UTF8);
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine($"Ошибка: Файл {filePath} не найден.");
            return;
        }


        Console.WriteLine("Содержимое responseText:");
        Console.WriteLine(responseText);
        Console.WriteLine(new string('-', 50));





      

        Console.ReadLine();
        Console.WriteLine(new string('-', 50));
    }


}
