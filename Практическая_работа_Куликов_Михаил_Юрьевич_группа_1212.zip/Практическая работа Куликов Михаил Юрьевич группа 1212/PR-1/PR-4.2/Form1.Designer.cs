﻿namespace PR_4._2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lst = new ListBox();
            lstFromfile = new ListBox();
            txt = new TextBox();
            btnAdd = new Button();
            btnSave = new Button();
            btnOpen = new Button();
            txtFileName = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // lst
            // 
            lst.FormattingEnabled = true;
            lst.Location = new Point(102, 156);
            lst.Name = "lst";
            lst.Size = new Size(197, 104);
            lst.TabIndex = 0;
            lst.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // lstFromfile
            // 
            lstFromfile.FormattingEnabled = true;
            lstFromfile.Location = new Point(342, 156);
            lstFromfile.Name = "lstFromfile";
            lstFromfile.Size = new Size(248, 104);
            lstFromfile.TabIndex = 1;
            // 
            // txt
            // 
            txt.Location = new Point(102, 341);
            txt.Name = "txt";
            txt.Size = new Size(197, 27);
            txt.TabIndex = 2;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(102, 374);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(197, 29);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Добавить в список";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(102, 288);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(197, 29);
            btnSave.TabIndex = 4;
            btnSave.Text = "Сохранить списов в фаил";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnOpen
            // 
            btnOpen.Location = new Point(342, 288);
            btnOpen.Name = "btnOpen";
            btnOpen.Size = new Size(248, 29);
            btnOpen.TabIndex = 5;
            btnOpen.Text = "загрузить данные из файла";
            btnOpen.UseVisualStyleBackColor = true;
            btnOpen.Click += button3_Click;
            // 
            // txtFileName
            // 
            txtFileName.Location = new Point(12, 60);
            txtFileName.Name = "txtFileName";
            txtFileName.Size = new Size(125, 27);
            txtFileName.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 37);
            label1.Name = "label1";
            label1.Size = new Size(98, 20);
            label1.TabIndex = 7;
            label1.Text = "Путь к файлу";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(txtFileName);
            Controls.Add(btnOpen);
            Controls.Add(btnSave);
            Controls.Add(btnAdd);
            Controls.Add(txt);
            Controls.Add(lstFromfile);
            Controls.Add(lst);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lst;
        private ListBox lstFromfile;
        private TextBox txt;
        private Button btnAdd;
        private Button btnSave;
        private Button btnOpen;
        private TextBox txtFileName;
        private Label label1;
    }
}
