namespace PR_2._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            int summa = Int32.Parse(txtB4.Text) + Int32.Parse(txtB3.Text) + Int32.Parse(txtB2.Text);
            txtB1.Text = summa.ToString();
        }
    }
}
