﻿namespace PR_2._1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCount = new Button();
            btnExit = new Button();
            txtB1 = new TextBox();
            txtB2 = new TextBox();
            txtB3 = new TextBox();
            txtB4 = new TextBox();
            SuspendLayout();
            // 
            // btnCount
            // 
            btnCount.Location = new Point(210, 220);
            btnCount.Name = "btnCount";
            btnCount.Size = new Size(94, 29);
            btnCount.TabIndex = 0;
            btnCount.Text = "Вычислить";
            btnCount.UseVisualStyleBackColor = true;
            btnCount.Click += btnCount_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(383, 220);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(94, 29);
            btnExit.TabIndex = 1;
            btnExit.Text = "Выход";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txtB1
            // 
            txtB1.Location = new Point(405, 68);
            txtB1.Name = "txtB1";
            txtB1.Size = new Size(125, 27);
            txtB1.TabIndex = 2;
            // 
            // txtB2
            // 
            txtB2.Location = new Point(274, 68);
            txtB2.Name = "txtB2";
            txtB2.Size = new Size(125, 27);
            txtB2.TabIndex = 3;
            txtB2.Text = "0";
            // 
            // txtB3
            // 
            txtB3.Location = new Point(143, 68);
            txtB3.Name = "txtB3";
            txtB3.Size = new Size(125, 27);
            txtB3.TabIndex = 4;
            txtB3.Text = "0";
            // 
            // txtB4
            // 
            txtB4.Location = new Point(12, 68);
            txtB4.Name = "txtB4";
            txtB4.Size = new Size(125, 27);
            txtB4.TabIndex = 5;
            txtB4.Text = "0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(540, 450);
            Controls.Add(txtB4);
            Controls.Add(txtB3);
            Controls.Add(txtB2);
            Controls.Add(txtB1);
            Controls.Add(btnExit);
            Controls.Add(btnCount);
            Name = "Form1";
            Text = "Вычисление_суммы";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCount;
        private Button btnExit;
        private TextBox txtB1;
        private TextBox txtB2;
        private TextBox txtB3;
        private TextBox txtB4;
    }
}
