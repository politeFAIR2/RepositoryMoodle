﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            int summa = Int32.Parse(txtA.Text) + Int32.Parse(txtB.Text)+ Int32.Parse(txtC.Text);
            txtSum.Text = summa.ToString();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // 1. Расстояние между автомобилями, удаляющимися друг от друга
            double V1 = double.Parse(txtV1.Text);
            double V2 = double.Parse(txtV2.Text);
            double initialDistance = 5; // км
            double T = double.Parse(txtT.Text); // часы
            double distanceApart = CalculateDistanceMovingApart(V1, V2, initialDistance, T);
            lblResult1.Text = $"Расстояние через {T} часов: {distanceApart} км";

            // 2. Расстояние между автомобилями, движущимися навстречу друг другу
            double distanceTowards = CalculateDistanceMovingTowards(V1, V2, initialDistance, T);
            lblResult2.Text = $"Расстояние через {T} часов: {distanceTowards} км";

            // 3. Решение линейного уравнения A*x + B = 0
            double A = double.Parse(txtA_1.Text);
            double B = double.Parse(txtB_1.Text);
            double x = SolveLinearEquation(A, B);
            lblResult3.Text = $"Решение уравнения: x = {x}";

            // 4. Периметр квадрата
            double a = double.Parse(txtSquareSide.Text);
            double perimeter = CalculateSquarePerimeter(a);
            lblResult4.Text = $"Периметр квадрата: {perimeter}";

            // 5. Площадь квадрата
            double area = CalculateSquareArea(a);
            lblResult5.Text = $"Площадь квадрата: {area}";

            // 6. Площадь и периметр прямоугольника
            double b = double.Parse(txtRectangleSideB.Text);
            double rectangleArea = CalculateRectangleArea(a, b);
            double rectanglePerimeter = CalculateRectanglePerimeter(a, b);
            lblResult6.Text = $"Площадь прямоугольника: {rectangleArea}, Периметр: {rectanglePerimeter}";

            // 7. Длина окружности
            double d = double.Parse(txtDiameter.Text);
            double circleLength = CalculateCircleLength(d);
            lblResult7.Text = $"Длина окружности: {circleLength}";

            // 8. Объем и площадь поверхности куба
            double cubeVolume = CalculateCubeVolume(a);
            double cubeSurfaceArea = CalculateCubeSurfaceArea(a);
            lblResult8.Text = $"Объем куба: {cubeVolume}, Площадь поверхности: {cubeSurfaceArea}";

            // 9. Объем и площадь поверхности прямоугольного параллелепипеда
            double c = double.Parse(txtCuboidSideC.Text);
            double cuboidVolume = CalculateCuboidVolume(a, b, c);
            double cuboidSurfaceArea = CalculateCuboidSurfaceArea(a, b, c);
            lblResult9.Text = $"Объем: {cuboidVolume}, Площадь поверхности: {cuboidSurfaceArea}";
 
            // 10. Длина окружности и площадь круга
            double R = double.Parse(txtRadius.Text);
            double circleLength2 = CalculateCircleLength2(R);
            double circleArea = CalculateCircleArea(R);
            lblResult10.Text = $"Длина окружности: {circleLength2}, Площадь круга: {circleArea}";

            // 11. Среднее арифметическое двух чисел
            double a2 = double.Parse(txtA_2.Text);
            double b2 = double.Parse(txtB_2.Text);
            double arithmeticMean = CalculateArithmeticMean(a2, b2);
            lblResult11.Text = $"Среднее арифметическое: {arithmeticMean}";

            // 12. Среднее геометрическое двух неотрицательных чисел
            double geometricMean = CalculateGeometricMean(a2, b2);
            lblResult12.Text = $"Среднее геометрическое: {geometricMean}";

            // 13. Сумма, разность, произведение и частное квадратов двух ненулевых чисел
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            var squaresResults = CalculateSquares(num1, num2);
            lblResult13.Text = $"Сумма: {squaresResults.Sum}, Разность: {squaresResults.Difference}, " +
                                   $"Произведение: {squaresResults.Product}, Частное: {squaresResults.Quotient}";

            // 14. Сумма, разность, произведение и частное модулей двух ненулевых чисел
            var absoluteResults = CalculateAbsoluteValues(num1, num2);
            lblResult14.Text = $"Сумма модулей: {absoluteResults.Sum}, Разность модулей: {absoluteResults.Difference}, " +
                                   $"Произведение модулей: {absoluteResults.Product}, Частное модулей: {absoluteResults.Quotient}";

            // 15. Гипотенуза и периметр прямоугольного треугольника
            double legA = double.Parse(txtLegA.Text);
            double legB = double.Parse(txtLegB.Text);
            double hypotenuse = CalculateHypotenuse(legA, legB);
            double perimeter2 = CalculateTrianglePerimeter(legA, legB, hypotenuse);
            lblResult15.Text = $"Гипотенуза: {hypotenuse}, Периметр: {perimeter2}";

            // 16. Решение системы линейных уравнений
            double A1 = double.Parse(txtA1.Text);
            double B1 = double.Parse(txtB1.Text);
            double C1 = double.Parse(txtC1.Text);
            double A2 = double.Parse(txtA2.Text);
            double B2 = double.Parse(txtB2.Text);
            double C2 = double.Parse(txtC2.Text);
            var systemResults = SolveLinearSystem(A1, B1, C1, A2, B2, C2);
            lblResult16.Text = $"x = {systemResults.X}, y = {systemResults.Y}";
            }
            
        
            //_____________________________________________

        // 1. Расстояние между автомобилями, удаляющимися друг от друга
        static double CalculateDistanceMovingApart(double V1, double V2, double initialDistance, double T)
        {
            return initialDistance + (V1 + V2) * T;
        }

        // 2. Расстояние между автомобилями, движущимися навстречу друг другу
        static double CalculateDistanceMovingTowards(double V1, double V2, double initialDistance, double T)
        {
            return Math.Abs(initialDistance - (V1 + V2) * T);
        }

        // 3. Решение линейного уравнения A*x + B = 0
        static double SolveLinearEquation(double A, double B)
        {
            if (A == 0)
                throw new ArgumentException("Коэффициент A не может быть равен 0.");
            return -B / A;
        }

        // 4. Периметр квадрата
        static double CalculateSquarePerimeter(double a)
        {
            return 4 * a;
        }

        // 5. Площадь квадрата
        static double CalculateSquareArea(double a)
        {
            return a * a;
        }

        // 6. Площадь прямоугольника
        static double CalculateRectangleArea(double a, double b)
        {
            return a * b;
        }

        // Периметр прямоугольника
        static double CalculateRectanglePerimeter(double a, double b)
        {
            return 2 * (a + b);
        }

        // 7. Длина окружности
        static double CalculateCircleLength(double d)
        {
            const double pi = 3.14;
            return pi * d;
        }

        // 8. Объем и площадь поверхности куба
        static double CalculateCubeVolume(double a)
        {
            return Math.Pow(a, 3);
        }

        static double CalculateCubeSurfaceArea(double a)
        {
            return 6 * Math.Pow(a, 2);
        }

        // 9. Объем и площадь поверхности прямоугольного параллелепипеда
        static double CalculateCuboidVolume(double a, double b, double c)
        {
            return a * b * c;
        }

        static double CalculateCuboidSurfaceArea(double a, double b, double c)
        {
            return 2 * (a * b + b * c + c * a);
        }

        // 10. Длина окружности и площадь круга
        static double CalculateCircleLength2(double R)
        {
            const double pi = 3.14;
            return 2 * pi * R;
        }

        static double CalculateCircleArea(double R)
        {
            const double pi = 3.14;
            return pi * Math.Pow(R, 2);
        }

        // 11. Среднее арифметическое двух чисел
        static double CalculateArithmeticMean(double a, double b)
        {
            return (a + b) / 2;
        }

        // 12. Среднее геометрическое двух неотрицательных чисел
        static double CalculateGeometricMean(double a, double b)
        {
            return Math.Sqrt(a * b);
        }

        // 13. Сумма, разность, произведение и частное квадратов двух ненулевых чисел
        static (double Sum, double Difference, double Product, double Quotient) CalculateSquares(double num1, double num2)
        {
            if (num1 == 0 || num2 == 0)
                throw new ArgumentException("Числа не должны быть равны нулю.");

            double square1 = Math.Pow(num1, 2);
            double square2 = Math.Pow(num2, 2);

            return (square1 + square2, square1 - square2, square1 * square2, square1 / square2);
        }

        // 14. Сумма, разность, произведение и частное модулей двух ненулевых чисел
        static (double Sum, double Difference, double Product, double Quotient) CalculateAbsoluteValues(double num1, double num2)
        {
            double absNum1 = Math.Abs(num1);
            double absNum2 = Math.Abs(num2);

            return (absNum1 + absNum2, absNum1 - absNum2, absNum1 * absNum2, absNum1 / absNum2);
        }

        // 15. Гипотенуза и периметр прямоугольного треугольника
        static double CalculateHypotenuse(double a, double b)
        {
            return Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));
        }

        static double CalculateTrianglePerimeter(double a, double b, double c)
        {
            return a + b + c;
        }

        // 16. Решение системы линейных уравнений
        static (double X, double Y) SolveLinearSystem(double A1, double B1, double C1, double A2, double B2, double C2)
        {
            double D = A1 * B2 - A2 * B1;
            if (D == 0)
                throw new ArgumentException("Система уравнений не имеет единственного решения.");

            double X = (C1 * B2 - C2 * B1) / D;
            double Y = (A1 * C2 - A2 * C1) / D;

            return (X, Y);
        }

        
    }
}
