﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.btnCount = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtV1 = new System.Windows.Forms.TextBox();
            this.txtV2 = new System.Windows.Forms.TextBox();
            this.txtT = new System.Windows.Forms.TextBox();
            this.lblResult1 = new System.Windows.Forms.Label();
            this.lblResult2 = new System.Windows.Forms.Label();
            this.lblResult3 = new System.Windows.Forms.Label();
            this.lblResult4 = new System.Windows.Forms.Label();
            this.lblResult5 = new System.Windows.Forms.Label();
            this.txtSquareSide = new System.Windows.Forms.TextBox();
            this.txtRectangleSideB = new System.Windows.Forms.TextBox();
            this.lblResult6 = new System.Windows.Forms.Label();
            this.lblResult7 = new System.Windows.Forms.Label();
            this.txtDiameter = new System.Windows.Forms.TextBox();
            this.lblResult8 = new System.Windows.Forms.Label();
            this.txtCuboidSideC = new System.Windows.Forms.TextBox();
            this.lblResult9 = new System.Windows.Forms.Label();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.lblResult10 = new System.Windows.Forms.Label();
            this.lblResult11 = new System.Windows.Forms.Label();
            this.lblResult12 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblResult13 = new System.Windows.Forms.Label();
            this.lblResult14 = new System.Windows.Forms.Label();
            this.txtLegA = new System.Windows.Forms.TextBox();
            this.txtLegB = new System.Windows.Forms.TextBox();
            this.lblResult15 = new System.Windows.Forms.Label();
            this.txtA1 = new System.Windows.Forms.TextBox();
            this.txtB1 = new System.Windows.Forms.TextBox();
            this.txtC1 = new System.Windows.Forms.TextBox();
            this.txtA2 = new System.Windows.Forms.TextBox();
            this.txtB2 = new System.Windows.Forms.TextBox();
            this.txtC2 = new System.Windows.Forms.TextBox();
            this.lblResult16 = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtA_1 = new System.Windows.Forms.TextBox();
            this.txtB_1 = new System.Windows.Forms.TextBox();
            this.txtA_2 = new System.Windows.Forms.TextBox();
            this.txtB_2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(12, 12);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(130, 22);
            this.txtA.TabIndex = 0;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(148, 12);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(112, 22);
            this.txtB.TabIndex = 1;
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(266, 12);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 22);
            this.txtC.TabIndex = 2;
            // 
            // txtSum
            // 
            this.txtSum.Location = new System.Drawing.Point(397, 12);
            this.txtSum.Name = "txtSum";
            this.txtSum.Size = new System.Drawing.Size(100, 22);
            this.txtSum.TabIndex = 3;
            // 
            // btnCount
            // 
            this.btnCount.Location = new System.Drawing.Point(12, 40);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(100, 23);
            this.btnCount.TabIndex = 4;
            this.btnCount.Text = "вычислить";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(118, 40);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 23);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtV1
            // 
            this.txtV1.Location = new System.Drawing.Point(13, 105);
            this.txtV1.Name = "txtV1";
            this.txtV1.Size = new System.Drawing.Size(100, 22);
            this.txtV1.TabIndex = 6;
            // 
            // txtV2
            // 
            this.txtV2.Location = new System.Drawing.Point(119, 105);
            this.txtV2.Name = "txtV2";
            this.txtV2.Size = new System.Drawing.Size(100, 22);
            this.txtV2.TabIndex = 7;
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(225, 105);
            this.txtT.Name = "txtT";
            this.txtT.Size = new System.Drawing.Size(100, 22);
            this.txtT.TabIndex = 8;
            // 
            // lblResult1
            // 
            this.lblResult1.AutoSize = true;
            this.lblResult1.Location = new System.Drawing.Point(343, 108);
            this.lblResult1.Name = "lblResult1";
            this.lblResult1.Size = new System.Drawing.Size(436, 16);
            this.lblResult1.TabIndex = 9;
            this.lblResult1.Text = "1. Расстояние между автомобилями, удаляющимися друг от друга";
            // 
            // lblResult2
            // 
            this.lblResult2.AutoSize = true;
            this.lblResult2.Location = new System.Drawing.Point(12, 149);
            this.lblResult2.Name = "lblResult2";
            this.lblResult2.Size = new System.Drawing.Size(483, 16);
            this.lblResult2.TabIndex = 10;
            this.lblResult2.Text = "2. Расстояние между автомобилями, движущимися навстречу друг другу";
            // 
            // lblResult3
            // 
            this.lblResult3.AutoSize = true;
            this.lblResult3.Location = new System.Drawing.Point(225, 183);
            this.lblResult3.Name = "lblResult3";
            this.lblResult3.Size = new System.Drawing.Size(290, 16);
            this.lblResult3.TabIndex = 11;
            this.lblResult3.Text = "3. Решение линейного уравнения A*x + B = 0";
            // 
            // lblResult4
            // 
            this.lblResult4.AutoSize = true;
            this.lblResult4.Location = new System.Drawing.Point(116, 222);
            this.lblResult4.Name = "lblResult4";
            this.lblResult4.Size = new System.Drawing.Size(151, 16);
            this.lblResult4.TabIndex = 12;
            this.lblResult4.Text = "4. Периметр квадрата";
            // 
            // lblResult5
            // 
            this.lblResult5.AutoSize = true;
            this.lblResult5.Location = new System.Drawing.Point(15, 257);
            this.lblResult5.Name = "lblResult5";
            this.lblResult5.Size = new System.Drawing.Size(143, 16);
            this.lblResult5.TabIndex = 13;
            this.lblResult5.Text = "5. Площадь квадрата";
            // 
            // txtSquareSide
            // 
            this.txtSquareSide.Location = new System.Drawing.Point(10, 219);
            this.txtSquareSide.Name = "txtSquareSide";
            this.txtSquareSide.Size = new System.Drawing.Size(100, 22);
            this.txtSquareSide.TabIndex = 14;
            // 
            // txtRectangleSideB
            // 
            this.txtRectangleSideB.Location = new System.Drawing.Point(10, 291);
            this.txtRectangleSideB.Name = "txtRectangleSideB";
            this.txtRectangleSideB.Size = new System.Drawing.Size(100, 22);
            this.txtRectangleSideB.TabIndex = 15;
            // 
            // lblResult6
            // 
            this.lblResult6.AutoSize = true;
            this.lblResult6.Location = new System.Drawing.Point(129, 294);
            this.lblResult6.Name = "lblResult6";
            this.lblResult6.Size = new System.Drawing.Size(267, 16);
            this.lblResult6.TabIndex = 16;
            this.lblResult6.Text = "6. Площадь и периметр прямоугольника";
            // 
            // lblResult7
            // 
            this.lblResult7.AutoSize = true;
            this.lblResult7.Location = new System.Drawing.Point(129, 334);
            this.lblResult7.Name = "lblResult7";
            this.lblResult7.Size = new System.Drawing.Size(142, 16);
            this.lblResult7.TabIndex = 17;
            this.lblResult7.Text = "7. Длина окружности";
            // 
            // txtDiameter
            // 
            this.txtDiameter.Location = new System.Drawing.Point(10, 328);
            this.txtDiameter.Name = "txtDiameter";
            this.txtDiameter.Size = new System.Drawing.Size(100, 22);
            this.txtDiameter.TabIndex = 18;
            // 
            // lblResult8
            // 
            this.lblResult8.AutoSize = true;
            this.lblResult8.Location = new System.Drawing.Point(15, 368);
            this.lblResult8.Name = "lblResult8";
            this.lblResult8.Size = new System.Drawing.Size(255, 16);
            this.lblResult8.TabIndex = 19;
            this.lblResult8.Text = "8. Объем и площадь поверхности куба";
            // 
            // txtCuboidSideC
            // 
            this.txtCuboidSideC.Location = new System.Drawing.Point(10, 397);
            this.txtCuboidSideC.Name = "txtCuboidSideC";
            this.txtCuboidSideC.Size = new System.Drawing.Size(100, 22);
            this.txtCuboidSideC.TabIndex = 20;
            // 
            // lblResult9
            // 
            this.lblResult9.AutoSize = true;
            this.lblResult9.Location = new System.Drawing.Point(129, 403);
            this.lblResult9.Name = "lblResult9";
            this.lblResult9.Size = new System.Drawing.Size(454, 16);
            this.lblResult9.TabIndex = 21;
            this.lblResult9.Text = "9. Объем и площадь поверхности прямоугольного параллелепипеда";
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(10, 435);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 22);
            this.txtRadius.TabIndex = 22;
            // 
            // lblResult10
            // 
            this.lblResult10.AutoSize = true;
            this.lblResult10.Location = new System.Drawing.Point(129, 441);
            this.lblResult10.Name = "lblResult10";
            this.lblResult10.Size = new System.Drawing.Size(259, 16);
            this.lblResult10.TabIndex = 23;
            this.lblResult10.Text = "10. Длина окружности и площадь круга";
            // 
            // lblResult11
            // 
            this.lblResult11.AutoSize = true;
            this.lblResult11.Location = new System.Drawing.Point(225, 482);
            this.lblResult11.Name = "lblResult11";
            this.lblResult11.Size = new System.Drawing.Size(275, 16);
            this.lblResult11.TabIndex = 24;
            this.lblResult11.Text = "11. Среднее арифметическое двух чисел";
            // 
            // lblResult12
            // 
            this.lblResult12.AutoSize = true;
            this.lblResult12.Location = new System.Drawing.Point(12, 508);
            this.lblResult12.Name = "lblResult12";
            this.lblResult12.Size = new System.Drawing.Size(389, 16);
            this.lblResult12.TabIndex = 25;
            this.lblResult12.Text = "12. Среднее геометрическое двух неотрицательных чисел";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(10, 544);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 22);
            this.txtNum1.TabIndex = 26;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(119, 544);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 22);
            this.txtNum2.TabIndex = 27;
            // 
            // lblResult13
            // 
            this.lblResult13.AutoSize = true;
            this.lblResult13.Location = new System.Drawing.Point(234, 544);
            this.lblResult13.Name = "lblResult13";
            this.lblResult13.Size = new System.Drawing.Size(532, 16);
            this.lblResult13.TabIndex = 28;
            this.lblResult13.Text = " 13. Сумма, разность, произведение и частное квадратов двух ненулевых чисел";
            // 
            // lblResult14
            // 
            this.lblResult14.AutoSize = true;
            this.lblResult14.Location = new System.Drawing.Point(15, 586);
            this.lblResult14.Name = "lblResult14";
            this.lblResult14.Size = new System.Drawing.Size(516, 16);
            this.lblResult14.TabIndex = 29;
            this.lblResult14.Text = "14. Сумма, разность, произведение и частное модулей двух ненулевых чисел";
            // 
            // txtLegA
            // 
            this.txtLegA.Location = new System.Drawing.Point(10, 617);
            this.txtLegA.Name = "txtLegA";
            this.txtLegA.Size = new System.Drawing.Size(100, 22);
            this.txtLegA.TabIndex = 30;
            // 
            // txtLegB
            // 
            this.txtLegB.Location = new System.Drawing.Point(119, 617);
            this.txtLegB.Name = "txtLegB";
            this.txtLegB.Size = new System.Drawing.Size(100, 22);
            this.txtLegB.TabIndex = 31;
            // 
            // lblResult15
            // 
            this.lblResult15.AutoSize = true;
            this.lblResult15.Location = new System.Drawing.Point(245, 623);
            this.lblResult15.Name = "lblResult15";
            this.lblResult15.Size = new System.Drawing.Size(387, 16);
            this.lblResult15.TabIndex = 32;
            this.lblResult15.Text = "15. Гипотенуза и периметр прямоугольного треугольника";
            // 
            // txtA1
            // 
            this.txtA1.Location = new System.Drawing.Point(10, 673);
            this.txtA1.Name = "txtA1";
            this.txtA1.Size = new System.Drawing.Size(100, 22);
            this.txtA1.TabIndex = 33;
            // 
            // txtB1
            // 
            this.txtB1.Location = new System.Drawing.Point(119, 673);
            this.txtB1.Name = "txtB1";
            this.txtB1.Size = new System.Drawing.Size(100, 22);
            this.txtB1.TabIndex = 34;
            // 
            // txtC1
            // 
            this.txtC1.Location = new System.Drawing.Point(225, 673);
            this.txtC1.Name = "txtC1";
            this.txtC1.Size = new System.Drawing.Size(100, 22);
            this.txtC1.TabIndex = 35;
            // 
            // txtA2
            // 
            this.txtA2.Location = new System.Drawing.Point(331, 673);
            this.txtA2.Name = "txtA2";
            this.txtA2.Size = new System.Drawing.Size(100, 22);
            this.txtA2.TabIndex = 36;
            // 
            // txtB2
            // 
            this.txtB2.Location = new System.Drawing.Point(437, 673);
            this.txtB2.Name = "txtB2";
            this.txtB2.Size = new System.Drawing.Size(100, 22);
            this.txtB2.TabIndex = 37;
            // 
            // txtC2
            // 
            this.txtC2.Location = new System.Drawing.Point(543, 673);
            this.txtC2.Name = "txtC2";
            this.txtC2.Size = new System.Drawing.Size(100, 22);
            this.txtC2.TabIndex = 38;
            // 
            // lblResult16
            // 
            this.lblResult16.AutoSize = true;
            this.lblResult16.Location = new System.Drawing.Point(649, 673);
            this.lblResult16.Name = "lblResult16";
            this.lblResult16.Size = new System.Drawing.Size(284, 16);
            this.lblResult16.TabIndex = 39;
            this.lblResult16.Text = "16. Решение системы линейных уравнений";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(857, 54);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(222, 34);
            this.btnCalculate.TabIndex = 40;
            this.btnCalculate.Text = "Start";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtA_1
            // 
            this.txtA_1.Location = new System.Drawing.Point(10, 177);
            this.txtA_1.Name = "txtA_1";
            this.txtA_1.Size = new System.Drawing.Size(100, 22);
            this.txtA_1.TabIndex = 41;
            // 
            // txtB_1
            // 
            this.txtB_1.Location = new System.Drawing.Point(119, 177);
            this.txtB_1.Name = "txtB_1";
            this.txtB_1.Size = new System.Drawing.Size(100, 22);
            this.txtB_1.TabIndex = 42;
            // 
            // txtA_2
            // 
            this.txtA_2.Location = new System.Drawing.Point(10, 476);
            this.txtA_2.Name = "txtA_2";
            this.txtA_2.Size = new System.Drawing.Size(100, 22);
            this.txtA_2.TabIndex = 43;
            // 
            // txtB_2
            // 
            this.txtB_2.Location = new System.Drawing.Point(119, 476);
            this.txtB_2.Name = "txtB_2";
            this.txtB_2.Size = new System.Drawing.Size(100, 22);
            this.txtB_2.TabIndex = 44;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1413, 771);
            this.Controls.Add(this.txtB_2);
            this.Controls.Add(this.txtA_2);
            this.Controls.Add(this.txtB_1);
            this.Controls.Add(this.txtA_1);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblResult16);
            this.Controls.Add(this.txtC2);
            this.Controls.Add(this.txtB2);
            this.Controls.Add(this.txtA2);
            this.Controls.Add(this.txtC1);
            this.Controls.Add(this.txtB1);
            this.Controls.Add(this.txtA1);
            this.Controls.Add(this.lblResult15);
            this.Controls.Add(this.txtLegB);
            this.Controls.Add(this.txtLegA);
            this.Controls.Add(this.lblResult14);
            this.Controls.Add(this.lblResult13);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblResult12);
            this.Controls.Add(this.lblResult11);
            this.Controls.Add(this.lblResult10);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.lblResult9);
            this.Controls.Add(this.txtCuboidSideC);
            this.Controls.Add(this.lblResult8);
            this.Controls.Add(this.txtDiameter);
            this.Controls.Add(this.lblResult7);
            this.Controls.Add(this.lblResult6);
            this.Controls.Add(this.txtRectangleSideB);
            this.Controls.Add(this.txtSquareSide);
            this.Controls.Add(this.lblResult5);
            this.Controls.Add(this.lblResult4);
            this.Controls.Add(this.lblResult3);
            this.Controls.Add(this.lblResult2);
            this.Controls.Add(this.lblResult1);
            this.Controls.Add(this.txtT);
            this.Controls.Add(this.txtV2);
            this.Controls.Add(this.txtV1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCount);
            this.Controls.Add(this.txtSum);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtSum;
        private System.Windows.Forms.Button btnCount;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtV1;
        private System.Windows.Forms.TextBox txtV2;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Label lblResult1;
        private System.Windows.Forms.Label lblResult2;
        private System.Windows.Forms.Label lblResult3;
        private System.Windows.Forms.Label lblResult4;
        private System.Windows.Forms.Label lblResult5;
        private System.Windows.Forms.TextBox txtSquareSide;
        private System.Windows.Forms.TextBox txtRectangleSideB;
        private System.Windows.Forms.Label lblResult6;
        private System.Windows.Forms.Label lblResult7;
        private System.Windows.Forms.TextBox txtDiameter;
        private System.Windows.Forms.Label lblResult8;
        private System.Windows.Forms.TextBox txtCuboidSideC;
        private System.Windows.Forms.Label lblResult9;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Label lblResult10;
        private System.Windows.Forms.Label lblResult11;
        private System.Windows.Forms.Label lblResult12;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblResult13;
        private System.Windows.Forms.Label lblResult14;
        private System.Windows.Forms.TextBox txtLegA;
        private System.Windows.Forms.TextBox txtLegB;
        private System.Windows.Forms.Label lblResult15;
        private System.Windows.Forms.TextBox txtA1;
        private System.Windows.Forms.TextBox txtB1;
        private System.Windows.Forms.TextBox txtC1;
        private System.Windows.Forms.TextBox txtA2;
        private System.Windows.Forms.TextBox txtB2;
        private System.Windows.Forms.TextBox txtC2;
        private System.Windows.Forms.Label lblResult16;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtA_1;
        private System.Windows.Forms.TextBox txtB_1;
        private System.Windows.Forms.TextBox txtA_2;
        private System.Windows.Forms.TextBox txtB_2;
    }
}

